unsigned int Echo;
unsigned int Distance;
unsigned char ch = 0x00;
#define ClockFreq 8000000 // 8 MGHz Fosc
#define TMR2PRESCALE 16
long PWM_freq = 5000; // period = 0.2 microseconds

void msDelay(unsigned int msCnt){
    unsigned int ms=0;
    unsigned int cc=0;
    for(ms=0;ms<(msCnt);ms++){
      for(cc=0;cc<155;cc++);//1ms
    }
}

void usDelay(unsigned int usCnt){
    unsigned int us=0;

    for(us=0;us<usCnt;us++){
      asm NOP;//0.5 uS
      asm NOP;//0.5uS
    }
}

void ultrasonic(void){
 TMR1H = 0; // THE INITIAL VALUE OF THE HIGHER 8 BITS
 TMR1L = 0; // THE INITIAL VALUE OF THE LOWER 8 BITS
 // echo(recieve) on RC0, and trigger(send) on RB1
 // PORTB = 0x00;
 PORTB = PORTB | 0x02; // RB1 HIGH, TRIGGER ON
 usDelay(10); // 10 micro seconds delay
 PORTB = PORTB & 0xFD; // RB1 LOW, TRIGGER OFF
 while(!(PORTC & 0x01)); // while echo = 0 wait for it to become 1 till the 8 cycle bursts finish
 T1CON = T1CON | 0X01; // TIMER STARTS
 while(PORTC & 0x01); // while echo = 1 the timer will be working till the echo falls to zero
 T1CON = T1CON & 0xFE; // TIMER OFF
 Echo = (TMR1L | (TMR1H<<8)); // Reads Timer Value
 Distance = Echo/58.82; // Converts Time to Distance

 // Distance Calibration
 if (Distance <= 15){ // here if Distance is < 7.5cm from car to pedestrian
   //TURN OFF MOTOR
   PORTB = PORTB & 0x0F; //turn off (RB7 and RB6 for motor 1 both off) (RB5 AND RB4 OFF) as if they are motors test case
   msDelay(5000); // the time to remove the pedestrian (5s)
 }
}

void PWM_initialize() {
     CCP1CON = 0X0C; //Configure the CCP1 module for PWM operation
     T2CON = 0x06; //TMR2 on with 1:16 Prescale
     PR2 = 250; // 8us * 250 = 2ms = PWM_Period
     TRISC = TRISC & 0xFB; // CCP1/RC2 Pin Output
}

void PWM_duty(unsigned int duty)  {
 if(duty<250) {// Make sure the duty cycle is within the PWM_Period
   //We will be using only 8 bits for the duty cycle
   //duty resolution = 8-bits
   CCPR1L = duty;// Store the 8 bits in the CCPR1L Reg
 }
}

void ir_sensors(void){
 // ir sensor left connected to RD2, ir sensor RIGHT connected to RD3
 // both ir sensors on: left ir sensor RD2=0 & RIGHT IR SENSOR RD3=0
 // sensor sees black = 1, sensor sees white = 0
  //while(1){
   ultrasonic();
   if (!(PORTD & 0x04) && !(PORTD & 0x08)) // left ir sees white, right ir sees white
        PORTB = 0x51;

   //left sensor RD2 only is over black line RD2=1, turn left
   ultrasonic();
   if((!(PORTD & 0x08)) && (PORTD&0x04)){ // right ir, left ir
    //PORTB = PORTB & 0x4F;// RB7,5,4=0 RB6 =1; MOTOR1 STOP, MOTOR2 ON
    PORTB = 0x41;
    //msDelay(100);
    //PORTB = PORTB | 0x40;
   }

   //RIGHT SENSOR IS OVER BLACK LINE RD3=1, turn right
   ultrasonic();
   if ((PORTD & 0x08) && (!(PORTD&0x04))){
    //PORTB = PORTB & 0x20;;//RB7,6,5=0, RB4 =1; MOTOR 1 ON , MOTOR 2 OFF
    PORTB = 0x11;
    //PORTB = PORTB | 0x10;
    //msDelay(100);
   }
}

void main(){
 TRISB = 0x01;// all output pins, RB0 input
 TRISC = 0x81;// all output pins, RC0 INPUT for Echo, RC7 input for serial comm
 TRISD = 0xFF;// all INPUT pins
 T1CON = 0x10; // initialize timer module
 PORTB = 0x00;
 msDelay(2000);
 PORTB = PORTB | 0x50;
 UART1_Init(9600);

 while(1) {
    if(UART1_Data_Ready()) { // to test if data in receive buffer is ready for reading
      ch = UART1_Read();

      // ir sensor left connected to RD2, ir sensor RIGHT connected to RD3
 // both ir sensors on: left ir sensor RD2=0 & RIGHT IR SENSOR RD3=0
 // sensor sees black = 1, sensor sees white = 0
  //while(1){
   ultrasonic();
   if (!(PORTD & 0x04) && !(PORTD & 0x08)) // left ir sees white, right ir sees white
        PORTB = 0x51;

   //left sensor RD2 only is over black line RD2=1, turn left
   ultrasonic();
   if((!(PORTD & 0x08)) && (PORTD&0x04)){ // right ir, left ir
    //PORTB = PORTB & 0x4F;// RB7,5,4=0 RB6 =1; MOTOR1 STOP, MOTOR2 ON
    PORTB = 0x41;
    //PORTB = PORTB | 0x40;
   }

   //RIGHT SENSOR IS OVER BLACK LINE RD3=1, turn right
   ultrasonic();
   if ((PORTD & 0x08) && (!(PORTD&0x04))){
    //PORTB = PORTB & 0x20;;//RB7,6,5=0, RB4 =1; MOTOR 1 ON , MOTOR 2 OFF
    PORTB = 0x11;
    //PORTB = PORTB | 0x10;

   }
      if (ch == 's') // 's' is code for stop
        PWM_duty(0);
      msDelay(10000);

    }


      if (ch == 'u') { // 'u' is code for speed up
        unsigned int j;
        for (j = 25; j < 201; j = j*2) {PWM_duty(j) ;}

      }



      if (ch == 'd') { // 'd' is code for slow down
        unsigned int i;
        for (i = 200; i>= 50; i = i/2) {PWM_duty(i) ;}

      }


  }

} // end of main