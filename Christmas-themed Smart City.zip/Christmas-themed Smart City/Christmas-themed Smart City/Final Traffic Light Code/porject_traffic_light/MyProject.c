// red is on rc2, orange is on rc1, green is on rc0
unsigned int count = 0;
void mymsDelay(unsigned int d) {   // with 256 prescaling
    count = 0;
    OPTION_REG = 0x87;
    TMR0 = 0;
    INTCON = INTCON | 0x20; // enable tmr0 overflow interrupt
    while(count < d);
    INTCON = INTCON & 0xdf; // disable tmr0 overflow interrupt
}

void interrupt(void)    { // this is the interrupt service routine for timer0
  if (INTCON & 0x04)       {   // if tmr0 interrupt flag is 1, execute the timer0 code
    TMR0 = 0; // start counting from 0-256 -> 256 times, overflows every 32 microseconds
    count++;
  }
  INTCON = INTCON & 0xfb; // clear t01f
}

void main()         {
  TRISB = 0x00; // port b output
  PORTB = 0x00;
  TRISC = 0x00; // port c output
  PORTC = 0x00;
  INTCON = 0xa0;
  UART1_Init(9600);

  while(1) {
    PORTC = 0x04; // turn on the red light for 5s
    UART1_Write('s');
    mymsDelay(157);

    PORTC = 0x02; // turn on the orange light for 5s
    mymsDelay(157);

    PORTC = 0x01; // turn on the green light for 15s
    UART1_Write('u');
    mymsDelay(469);

    PORTC = 0x02; // turn on the orange light for 5s
    UART1_Write('d');
    mymsDelay(157);

    PORTC = 0x04; // turn on the red light for 5s
    UART1_Write('s');
    mymsDelay(157);
  }
}